import { HttpClient, HttpHandler } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { APIServiceService } from 'src/app/apiservice.service';
import { Chatbot2Component } from 'src/app/chatbot2/chatbot2.component';
@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {

  loginInfo: any = {};
  LoginName: any = {};
  LoginName1: any = {};
  profileType : any;
  Chatbots : any={};
  constructor(private router: Router,private APIServiceService: APIServiceService,private changeDetectorRef: ChangeDetectorRef) {

    this.loginInfo = JSON.parse(localStorage.getItem('user') || '[]');
    console.log( this.loginInfo);
    this.profileType = this.loginInfo.profiletype;
    // this.LoginName=this.LoginName1.Loginname;
    this.Chatbots=this.loginInfo;

    
    console.log( this.Chatbots);
  }

  selectedChatbotID: number=0;
  DashboardStyle: string = "";
  ProfileStyle: string = "";
  DeviceManagementStyle: string = "";
  SettingsStyle: string = "";
  PlanManagementStyle: string = "";
  AccountStyle: string = "";
  EmployeeStyle: string = "";
  SupportStyle: string = "";
  SimMgmntStyle: string = "";
  AMCMgmntStyle: string = "";
  UserAMCMgmntStyle: string = "";
  DeviceInventoryMgmntStyle: string = "";
  ReportStyle: string = "";
  SupportedDeviceStyle: string = "";
  MaintenanceStyle: string = "";
  DriverDataStyle: string = "";
  InstallationDetailsStyle: string = "";
  TransferDeviceStyle: string = "";

  ngOnInit(): void {
    //check whether ISloggedIn is true or not

    if (localStorage.getItem('user') != null) {
      //show hide required menus 
    }
    else {
      //redirect to login for authorized user
      this.router.navigate(['login'])
    }
  }
  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    //check whether ISloggedIn is true or not

    if (localStorage.getItem('user') != null) {
      //show hide required menus 
    }
    else {
      //redirect to login for authorized user
      this.router.navigate(['login'])
    }
  }
  get isAdmin() {

    if (this.loginInfo && this.loginInfo.role === 'Admin')
      return this.loginInfo.role;
  }

  get isUser() {
    if (this.loginInfo && this.loginInfo.role === 'User')
      return this.loginInfo.role;
   
  }

  get isSupport() {
    if (this.loginInfo && this.loginInfo.role === 'Support')
      return this.loginInfo.role;
  }
  get isMreseller() {

    if (this.loginInfo && this.loginInfo.role === 'Master Reseller')
      return this.loginInfo.role;
  }
  get isReseller() {
    if (this.loginInfo && this.loginInfo.role === 'Reseller')
      return this.loginInfo.role;
  }
  get isAdminUser() {//60c2f4224843bf0bd431eda9
    if (this.loginInfo && this.loginInfo.role === 'User')// && this.loginInfo.mrid == 0
      return this.loginInfo.role;
  }

  


  onChatbotSelect(event: any) {
    debugger;
    this.selectedChatbotID = event.target.value; // Get the selected value (ChatbotID)

     //if (this.selectedChatbotID){
      this.router.navigate(['/chatbot'],{queryParams:{id : [this.selectedChatbotID]}
       });
     //}
    console.log('Selected ChatbotID:', this.selectedChatbotID);
    //this.selectedChatbotID = event.target.value;
    //this.APIServiceService.setSelectedChatbotID(this.selectedChatbotID);

    //const Chatbot2=new Chatbot2Component(this.APIServiceService,this.changeDetectorRef);
    //Chatbot2.changeChatBot();
    //Chatbot2.ngOnInit();
    //this.router.navigate(['/Chatbot'])

      // You can perform further actions with the selected value here

       // Navigate to Chatbot2Component and pass selectedChatbotID as a route parameter
    
      
   }
 
}
